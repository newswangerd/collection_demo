

# Collection Demo Guide

Welcome to the Collection Demo Guide!

The purpose of this guide add some documentation to the Ansible  [Collection Demo](https://github.com/newswangerd/collection_demo) for test purposes only.

To get started, please select one of the following topics.

* [What's this demo collection](demo_intro.md)
* [Playbook examples](demo_tasks.md)
* [Sample reference tables](demo_reference.md)
