# What is a collection?

A collection is a distribution format for delivering all types of Ansible Content.

This collection contains a demo module: `real_facts` and a role: `factoid` that can be used
to show off the capabilities of collections.
